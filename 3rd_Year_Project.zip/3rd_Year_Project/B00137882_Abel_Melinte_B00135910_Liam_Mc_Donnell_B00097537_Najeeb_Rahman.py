import wmi #implementeed WMI (Windows Management Instrumentation)
import tkinter as tk #added tkinter, also known as the python GUI
from tkinter import * 
import platform #added platform to see the specs contained in a system

def cpu(): #function created
    c = wmi.WMI()#calling the WMI class
    cpu = c.Win32_Processor()[0] #retrieve processor from system
    return cpu.Name.strip() #return the CPU model name

def ram(): #function created
    c = wmi.WMI() #calling the WMI class
    total_ram = 0 #set variable to 0
    for RAM in c.Win32_PhysicalMemory(): #captures any memory that WMI finds
        total_ram += int(RAM.Capacity) #converts string result into a integer
    return total_ram / (1024 ** 3)  # the total ram gets divided by 1024 to the power of 3 (converts from byte to gigabyte)

def system(): #function created
    system_info = [] #created an empty list
    system_info.append(f"System: {platform.system()}") #takes the name of the operating system
    return system_info #returns info as the output

def gpu(): #declared a function named gpu
    c = wmi.WMI() #calling the WMI class
    found = False #set the flag to false
    for GPU in c.Win32_VideoController(): #created a for loop named "GPU"
        if 'AMD' in GPU.Name: #if there is a videocontroller named "AMD"
            result_label.config(text=f'AMD GPU Name: {GPU.Name}') #return to me the present GPU within the system
            found = True #set the flag to true
            break #stop
    if not found: #if the specific GPU is not detected then return this
        result_label.config(text='No AMD GPU found.', bg="green") #this returns when not detected "AMD"

    cpu_model = cpu()#retrieves the CPU model name
    result_label_cpu.config(text=f'CPU Model: {cpu_model}')#format of result

    for GPU in c.Win32_VideoController(): #created a for loop named "GPU"
        if 'NVIDIA' in GPU.Name: #if there is a videocontroller name "NVIDIA"
            result_label.config(text=f'NVIDIA GPU Name: {GPU.Name}') #return to me the present GPU witin the system
            found = True #set the flag to true
            break #stop
    if not found: #if the NVIDIA GPU isn't found
        result_label.config(text='No NVIDIA GPU found.') #return me this text so it shows that it isn't detected.
        
    cpu_model = cpu() #retrieves the CPU model name
    result_label_cpu.config(text=f'CPU Model: {cpu_model}') #how the result should be displayed

    total_ram = ram() #returns the system RAM
    result_label_ram.config(text=f'Total RAM: {total_ram:.2f} GB') #displays the value of the variable

    system_info = system() #function retrieves the information
    result_label_system.config(text="\n".join(system_info)) #creates a string of the retrieved system info from that function

root = tk.Tk() #created a tk gui window to display when the code is executed

root.title("GPU Detector") #added a title to the GUI

amd_button = tk.Button(root, text="Check Advanced System Information!", command=gpu, bg="green") #added a button
amd_button.pack() #added the button to the group

result_label = tk.Label(root, text="") #added a empty string so it displays the active GPU within the system
result_label.pack() #added the text to the group

result_label_cpu = tk.Label(root, text="") ##added a empty string so it displays the active CPU within the system
result_label_cpu.pack()#added the text to the group

result_label_ram = tk.Label(root, text="") #added an empty string so it displays the RAM that is within the system
result_label_ram.pack() #added the text to the group

result_label_system = tk.Label(root, text="")#added an empty string so it displays the RAM that is within the system
result_label_system.pack()#added the text to the group
root.mainloop() #displays the GUI continuously since it's looped.

#Microsoft (N/A). Windows App Development [Online] Available at: https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-videocontroller [Accessed: 11 March 2023].
#Python Software Foundation. (N/A). tkinter — Python interface to Tcl/Tk. [Online] Available at: https://docs.python.org/3/library/tkinter.html [Accessed: 11 March 2023].
#Golden, T. (2005). Tim Golden's Python Stuff: WMI Cookbook. [Online] Available at: http://timgolden.me.uk/python/wmi/cookbook.html [Accessed: 11 March 2023].